

<?php $__env->startSection('main'); ?>
    <section class="bg-white dark:bg-gray-900">
        <div class="max-w-screen-xl px-4 py-8">

            <?php echo $chart->container(); ?>

            <?php echo $chart1->container(); ?>


            <script src="<?php echo e($chart->cdn()); ?>"></script>
            <?php echo e($chart->script()); ?>

            <script src="<?php echo e($chart1->cdn()); ?>"></script>
            <?php echo e($chart1->script()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\faricAndre\Documents\laravel\shamo\resources\views/pages/report/index.blade.php ENDPATH**/ ?>