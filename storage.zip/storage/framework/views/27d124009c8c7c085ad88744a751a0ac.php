<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo e($title ?? 'Error'); ?></title>

    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('site.webmanifest')); ?>">

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.7.0/flowbite.min.css" rel="stylesheet" />

    <?php echo $__env->make('components.config', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        // On page load or when changing themes, best to add inline in `head` to avoid FOUC
        if (localStorage.getItem('color-theme') === 'dark' || (!('color-theme' in localStorage) && window.matchMedia(
                '(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark')
        }
    </script>
</head>

<body class="bg-white dark:bg-gray-900">

    <?php echo $__env->yieldContent('main'); ?>

    <?php echo $__env->make('components.toast', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.7.0/flowbite.min.js"></script>

    <script>
        // Menutup toast secara otomatis setelah 5 detik
        setTimeout(function() {
            var successToast = document.getElementById('toast-success');
            var errorToast = document.getElementById('toast-error');
            var warningToast = document.getElementById('toast-warning');

            if (successToast) {
                successToast.classList.add('hidden');
            }

            if (errorToast) {
                errorToast.classList.add('hidden');
            }

            if (warningToast) {
                warningToast.classList.add('hidden');
            }
        }, 5000);
    </script>

</body>

</html>
<?php /**PATH C:\Users\faricAndre\Documents\laravel\shamo\resources\views/layouts/simple.blade.php ENDPATH**/ ?>